// ARCHIVED: original backend script moved to archive/archived_2026-01-08/backend_scripts/seed_demo.js
// See archive/archived_2026-01-08/backend_scripts/seed_demo.js for original content.

